
  # Should I Race This?

  This is a code bundle for Should I Race This?. The original project is available at https://www.figma.com/design/6OGZxmwacCoMRh3HaiZwRZ/Should-I-Race-This-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  